import { Component } from '@angular/core';
interface Expense {
  description: string;
  category: string;
  amount: number;
}
@Component({
  selector: 'app-expenses',
  templateUrl: './expenses.component.html',
  styleUrls: ['./expenses.component.css']
})
export class ExpensesComponent {
  description: string = '';
  category: string = '';
  amount: number | null = null;

  categories: string[] = ['Food', 'Travel', 'Utilities', 'Shopping', 'Health', 'Other'];
  expenses: any[] = [];
  filteredExpenses: any[] = [];

  selectedCategory: string = 'All';
  totalExpense: number = 0;

  ngOnInit(): void {
    this.updateFilteredExpenses();
  }

  addExpense(): void {
    if (this.description && this.category && this.amount !== null) {
      const newExpense = {
        description: this.description,
        category: this.category,
        amount: +this.amount
      };
      this.expenses.push(newExpense);
      this.updateFilteredExpenses();
      this.resetForm();
      this.calculateTotal();
    }
  }

  removeExpense(index: number): void {
    const globalIndex = this.expenses.indexOf(this.filteredExpenses[index]);
    if (globalIndex > -1) {
      this.expenses.splice(globalIndex, 1);
    }
    this.updateFilteredExpenses();
    this.calculateTotal();
  }

  removeAllExpenses(): void {
    if (confirm('Are you sure you want to delete all expenses?')) {
      this.expenses = [];
      this.filteredExpenses = [];
      this.totalExpense = 0;
    }
  }

  updateFilteredExpenses(): void {
    if (this.selectedCategory === 'All') {
      this.filteredExpenses = [...this.expenses];
    } else {
      this.filteredExpenses = this.expenses.filter(
        exp => exp.category === this.selectedCategory
      );
    }
    this.calculateTotal();
  }

  calculateTotal(): void {
    this.totalExpense = this.filteredExpenses.reduce(
      (acc, exp) => acc + exp.amount, 0
    );
  }

  resetForm(): void {
    this.description = '';
    this.category = '';
    this.amount = null;
  }
}