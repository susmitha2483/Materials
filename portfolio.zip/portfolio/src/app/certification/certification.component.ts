import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-certification',
  templateUrl: './certification.component.html',
  styleUrls: ['./certification.component.css']
})
export class CertificationComponent {
  certificate:any[]=[];
  constructor( private http: HttpClient){}
  ngOnInit():void{
    this.http.get<any>('assets/json/data.json').subscribe(data=>{
      this.certificate=data.certifications;
    });
  }
}
