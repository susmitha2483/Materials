import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-projects',
  templateUrl: './projects.component.html',
  styleUrls: ['./projects.component.css']
})
export class ProjectsComponent {

  projects:any[]=[];
  constructor( private http: HttpClient){}
  ngOnInit():void{
    this.http.get<any>('assets/json/data.json').subscribe(data=>{
      this.projects=data.projects;
    });
  }
}