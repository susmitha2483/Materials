import { HttpClient } from '@angular/common/http';
import { Component } from '@angular/core';

@Component({
  selector: 'app-education',
  templateUrl: './education.component.html',
  styleUrls: ['./education.component.css']
})
export class EducationComponent {
  education:any[]=[];
  constructor( private http: HttpClient){}
  ngOnInit():void{
    this.http.get<any>('assets/json/data.json').subscribe(data=>{
      this.education=data.education;
    });
  }
}
