import { Component, OnInit } from '@angular/core';

export interface Question {
  question: string;
  options: string[];
  answer: string;
  explanation?: string;
}

export interface LeaderboardEntry {
  name: string;
  score: number;
  date: string;
}

export const QUIZ_DATA: Question[] = [
  {
    question: 'What is the capital of France?',
    options: ['Paris', 'London', 'Berlin', 'Madrid'],
    answer: 'Paris',
    explanation: 'Paris is the capital city of France.',
  },
  {
    question: 'What is 2 + 2?',
    options: ['3', '4', '5', '6'],
    answer: '4',
    explanation: '2 + 2 equals 4.',
  },
  {
    question: 'Which planet is known as the Red Planet?',
    options: ['Earth', 'Mars', 'Venus', 'Jupiter'],
    answer: 'Mars',
    explanation: 'Mars is called the Red Planet due to its reddish appearance.',
  },
  {
    question: 'Who wrote "Romeo and Juliet"?',
    options: ['William Shakespeare', 'Leo Tolstoy', 'Mark Twain', 'Charles Dickens'],
    answer: 'William Shakespeare',
    explanation: 'Shakespeare wrote the famous play "Romeo and Juliet".',
  },
  {
    question: 'Which gas do plants absorb from the atmosphere?',
    options: ['Oxygen', 'Hydrogen', 'Nitrogen', 'Carbon Dioxide'],
    answer: 'Carbon Dioxide',
    explanation: 'Plants absorb carbon dioxide during photosynthesis.',
  },
  {
    question: 'What is the boiling point of water at sea level?',
    options: ['100°C', '90°C', '80°C', '110°C'],
    answer: '100°C',
    explanation: 'Water boils at 100 degrees Celsius at sea level.',
  },
  {
    question: 'Who was the first person to walk on the Moon?',
    options: ['Buzz Aldrin', 'Neil Armstrong', 'Yuri Gagarin', 'Michael Collins'],
    answer: 'Neil Armstrong',
    explanation: 'Neil Armstrong was the first person to walk on the Moon in 1969.',
  },
  {
    question: 'What is the largest mammal in the world?',
    options: ['Elephant', 'Blue Whale', 'Giraffe', 'Hippopotamus'],
    answer: 'Blue Whale',
    explanation: 'The Blue Whale is the largest known mammal on Earth.',
  },
  {
    question: 'Which language is primarily spoken in Brazil?',
    options: ['Spanish', 'Portuguese', 'English', 'French'],
    answer: 'Portuguese',
    explanation: 'Portuguese is the official language of Brazil.',
  },
  {
    question: 'Which continent is the Sahara Desert located in?',
    options: ['Asia', 'Africa', 'Australia', 'South America'],
    answer: 'Africa',
    explanation: 'The Sahara Desert is in North Africa.',
  }
];

@Component({
  selector: 'app-quiz',
  templateUrl: './quiz.component.html',
  styleUrls: ['./quiz.component.css']
})
export class QuizComponent implements OnInit {
  questions: Question[] = QUIZ_DATA;
  currentIndex = 0;
  score = 0;
  selectedOption = '';
  feedback = '';
  showFeedback = false;
  timer = 60;
  interval: any;
  showResult = false;

  correctAnswers = 0;
  incorrectAnswers = 0;

  leaderboard: LeaderboardEntry[] = [];

  ngOnInit(): void {
    this.loadFromStorage();
    this.startTimer();
    this.loadLeaderboard();
  }

  startTimer() {
    this.clearTimer();
    this.interval = setInterval(() => {
      this.timer--;
      this.saveToStorage();
      if (this.timer <= 0) {
        clearInterval(this.interval);
        this.endQuiz();
      }
    }, 1000);
  }

  clearTimer() {
    if (this.interval) {
      clearInterval(this.interval);
    }
  }

  selectOption(option: string) {
    this.selectedOption = option;
  }

  submitAnswer() {
    if (!this.selectedOption) return;

    const currentQuestion = this.questions[this.currentIndex];

    if (this.selectedOption === currentQuestion.answer) {
      this.score++;
      this.feedback = '✅ Correct!';
      this.correctAnswers++;
    } else {
      this.feedback = `❌ Incorrect! Correct answer: ${currentQuestion.answer}`;
      this.incorrectAnswers++;
    }

    this.showFeedback = true;
    this.saveToStorage();

    setTimeout(() => {
      this.nextQuestion();
    }, 1500);
  }

  nextQuestion() {
    this.selectedOption = '';
    this.showFeedback = false;
    this.feedback = '';

    if (this.currentIndex < this.questions.length - 1) {
      this.currentIndex++;
      this.startTimer();
    } else {
      this.endQuiz();
    }
    this.saveToStorage();
  }

  endQuiz() {
    this.clearTimer();
    this.showResult = true;
    localStorage.removeItem('quizData');

    const name = prompt('🎉 Quiz completed! Enter your name for the leaderboard:');
    if (name) {
      this.saveToLeaderboard(name);
    }
  }

  restartQuiz() {
    this.currentIndex = 0;
    this.score = 0;
    this.selectedOption = '';
    this.feedback = '';
    this.showFeedback = false;
    this.timer = 60;
    this.showResult = false;
    this.correctAnswers = 0;
    this.incorrectAnswers = 0;
    this.startTimer();
    this.saveToStorage();
  }

  get progressPercent(): number {
    return ((this.currentIndex + 1) / this.questions.length) * 100;
  }

  saveToStorage() {
    const data = {
      currentIndex: this.currentIndex,
      score: this.score,
      timer: this.timer,
      correctAnswers: this.correctAnswers,
      incorrectAnswers: this.incorrectAnswers
    };
    localStorage.setItem('quizData', JSON.stringify(data));
  }

  loadFromStorage() {
    const saved = localStorage.getItem('quizData');
    if (saved) {
      const data = JSON.parse(saved);
      this.currentIndex = data.currentIndex;
      this.score = data.score;
      this.timer = data.timer;
      this.correctAnswers = data.correctAnswers;
      this.incorrectAnswers = data.incorrectAnswers;
    }
  }

  saveToLeaderboard(name: string) {
    const entry: LeaderboardEntry = {
      name,
      score: this.score,
      date: new Date().toLocaleDateString()
    };
    this.leaderboard.push(entry);
    localStorage.setItem('leaderboard', JSON.stringify(this.leaderboard));
  }

  loadLeaderboard() {
    const data = localStorage.getItem('leaderboard');
    if (data) {
      this.leaderboard = JSON.parse(data);
    }
  }
}
