const express = require('express');
const CartItem = require('../models/cart');
const Product = require('../models/product');
const router = express.Router();

// Get all cart items
router.get('/', async (req, res) => {
  const items = await CartItem.find();
  res.json(items);
});

// Add item to cart
router.post('/', async (req, res) => {
  const item = req.body;
  let existingItem = await CartItem.findOne({ productId: item.productId });

  if (existingItem) {
    existingItem.quantity += 1;
    await existingItem.save();
  } else {
    const newItem = new CartItem({ ...item, quantity: 1 });
    await newItem.save();
  }
  res.status(201).json({ message: 'Added to cart' });
});

// Update quantity
router.put('/:productId', async (req, res) => {
  const { quantity } = req.body;
  await CartItem.updateOne({ productId: req.params.productId }, { $set: { quantity } });
  res.json({ message: 'Quantity updated' });
});

// Cart count
router.get('/count', async (req, res) => {
  const items = await CartItem.find();
  const count = items.reduce((sum, item) => sum + item.quantity, 0);
  res.json({ count });
});
router.delete('/:productId', async (req, res) => {
  await CartItem.deleteOne({ productId: req.params.productId });
  res.json({ message: 'Item removed' });
});

module.exports = router;
