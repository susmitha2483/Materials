// models/cart.js
const mongoose = require('mongoose');

const cartSchema = new mongoose.Schema({
    productId: Number,
  title: String,
  price: Number,
  discountPercentage:Number,
  quantity: { type: Number, default: 1 },
  image: String,
  stock: Number
});

module.exports = mongoose.model('Cart', cartSchema);
