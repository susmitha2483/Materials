import { Component, OnInit } from '@angular/core';
import { CartItem, CartService } from '../cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {
  cartItems: CartItem[] = [];

  constructor(private cartService: CartService,private router: Router) { }


  ngOnInit(): void {
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;
    });
  }
getDiscountedPrice(item: CartItem): number {
  const discount = item.product.discountPercentage || 0;
  const price = item.product.price;
  return price * (1 - discount / 100) * item.quantity;
}

getDiscountAmount(item: CartItem): number {
  const discount = item.product.discountPercentage || 0;
  const price = item.product.price;
  return price * (discount / 100) * item.quantity;
}


  removeItem(productId: string): void {
    this.cartService.removeFromCart(productId);
  }

 decreaseQuantity(item: CartItem): void {
  const newQuantity = item.quantity - 1;
  this.cartService.updateQuantity(item.product._id, newQuantity);
}

increaseQuantity(item: CartItem): void {
  const newQuantity = item.quantity + 1;
  this.cartService.updateQuantity(item.product._id, newQuantity);
}

getTotal(): number {
  return this.cartItems.reduce((sum, item) => sum + this.getDiscountedPrice(item), 0);
}
goToCheckout(): void {
  this.router.navigate(['/home/products/cart/checkout']);
}

}