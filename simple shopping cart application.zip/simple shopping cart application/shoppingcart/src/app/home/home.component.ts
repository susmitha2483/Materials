import { Component } from '@angular/core';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  fewProducts:any[]=[];
  constructor( private ps:ProductService){}
  ngOnInit(){
    this.ps.getFewProducts().subscribe((data:any)=>{
      this.fewProducts=data;
    })
  }
}
