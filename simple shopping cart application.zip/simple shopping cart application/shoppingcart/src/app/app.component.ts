import { Component } from '@angular/core';
import { CartService } from './cart.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'shoppingcart';
   cartItemCount = 0;

  constructor(private cartService: CartService) {}

 ngOnInit(): void {
  this.cartService.cart$.subscribe(items => {
    // Number of distinct products is just the length of the cart array
    this.cartItemCount = items.length;
  });
}

}
