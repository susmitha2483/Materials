import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ProductListComponent } from './product-list/product-list.component';
import { CartComponent } from './cart/cart.component';
import { HomeComponent } from './home/home.component';
import { CheckoutComponent } from './checkout/checkout.component';

const routes: Routes = [
  {
    path: 'home',
    component: HomeComponent,
    data: { breadcrumb: 'Home' },
    children: [
      {
        path: 'products',
        component: ProductListComponent,
        data: { breadcrumb: 'Products' },
        children: [
          {
            path: 'cart',
            component: CartComponent,
            data: { breadcrumb: 'Cart' },
            children: [
              {
                path: 'checkout',
                component: CheckoutComponent,
                data: { breadcrumb: 'Checkout' }
              }
            ]
          }
        ]
      }
    ]
  },
  {
    path: '',
    redirectTo: 'home',
    pathMatch: 'full'
  }
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
