import { Component, OnInit } from '@angular/core';
import { ProductService, Product } from '../product.service';
import { CartService, CartItem } from '../cart.service';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {
  products: Product[] = [];
  filteredProducts: Product[] = [];
  search: string = '';
  category: string = '';
  uniqueCategories: string[] = [];

  cartItems: CartItem[] = [];

  constructor(private productService: ProductService, private cartService: CartService) {}

  ngOnInit(): void {
    this.productService.getProducts().subscribe(products => {
      this.products = products;
      this.uniqueCategories = [...new Set(products.map(p => p.category))];
      this.filter();
    });

    // Subscribe to cart changes
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;
    });
  }

  filter(): void {
    this.filteredProducts = this.products.filter(product =>
      product.title.toLowerCase().includes(this.search.toLowerCase()) &&
      (this.category ? product.category === this.category : true)
    );
  }

  getQuantity(productId: string): number {
    const item = this.cartItems.find(i => i.product._id === productId);
    return item ? item.quantity : 0;
  }

  addToCart(product: Product): void {
    this.cartService.addToCart(product);
    // alert can be removed or kept based on your preference
    alert(`${product.title} added to cart`);
  }

  increaseQuantity(productId: string): void {
    const currentQty = this.getQuantity(productId);
    this.cartService.updateQuantity(productId, currentQty + 1);
  }

  decreaseQuantity(productId: string): void {
    const currentQty = this.getQuantity(productId);
    if (currentQty > 1) {
      this.cartService.updateQuantity(productId, currentQty - 1);
    } else {
      this.cartService.removeFromCart(productId);
    }
  }
}
