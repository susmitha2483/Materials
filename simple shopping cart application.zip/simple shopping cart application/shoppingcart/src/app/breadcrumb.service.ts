// breadcrumb.service.ts
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, NavigationEnd, Router } from '@angular/router';
import { BehaviorSubject, filter } from 'rxjs';

export interface Breadcrumb {
  label: string;
  url: string;
}
@Injectable({ providedIn: 'root' })
export class BreadcrumbService {
  private breadcrumbsSubject = new BehaviorSubject<Breadcrumb[]>([]);
  breadcrumbs$ = this.breadcrumbsSubject.asObservable();

  constructor(private router: Router) {
   this.router.events.pipe(
  filter(event => event instanceof NavigationEnd)
).subscribe(() => {
  const root = this.router.routerState.snapshot.root;
  const breadcrumbs: Breadcrumb[] = [];
  this.buildBreadcrumbs(root, '', breadcrumbs);
  console.log('All breadcrumbs:', breadcrumbs);
  this.breadcrumbsSubject.next(breadcrumbs);
});



  }

private buildBreadcrumbs(route: ActivatedRouteSnapshot, url: string, breadcrumbs: Breadcrumb[]) {
  if (route) {
    // Compose route URL
    const routeUrl = route.url.map(segment => segment.path).join('/');
    const nextUrl = routeUrl ? (url.endsWith('/') ? url + routeUrl : url + '/' + routeUrl) : url;

    // Add breadcrumb if exists
    if (route.data['breadcrumb']) {
      breadcrumbs.push({
        label: route.data['breadcrumb'],
        url: nextUrl || '/'
      });
    }

    // Recursively call for first child only (path down the active route)
    if (route.firstChild) {
      this.buildBreadcrumbs(route.firstChild, nextUrl, breadcrumbs);
    }
  }
}

}

