// product.service.ts
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

export interface Product {
  _id: string;
  title: string;
  price: number;
  discountPercentage: number;
  description: string;
  category: string;
  image?: string;
  stock: number;
}

@Injectable({
  providedIn: 'root'
})
export class ProductService { 
  private apiUrl = 'http://localhost:3000/api/productsss';  // Backend URL

  constructor(private http: HttpClient) {}

  // Fetch all products from the backend
  getProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(this.apiUrl);
  }

  // Fetch few products
  getFewProducts(): Observable<Product[]> {
    return this.http.get<Product[]>(`${this.apiUrl}/featured`);
  }

  // ✅ Fetch single product by ID
  getProductById(id: string): Observable<Product> {
    return this.http.get<Product>(`${this.apiUrl}/${id}`);
  }
}
