import { Component } from '@angular/core';
import { CartItem, CartService } from '../cart.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent {
  cartItems: CartItem[] = [];

  shipping = {
    fullName: '',
    email: '',
    address: '',
    city: '',
    state: '',
    zip: ''
  };

  paymentMethod = '';

  constructor(private cartService: CartService, private router: Router) {}

  ngOnInit(): void {
    this.cartService.cart$.subscribe(items => {
      this.cartItems = items;
      if (this.cartItems.length === 0) {
        this.router.navigate(['/products']);
      }
    });
  }

  getTotal(): number {
    return this.cartItems.reduce((sum, item) => sum + item.product.price * item.quantity, 0);
  }

  placeOrder(): void {
    if (this.paymentMethod && this.isShippingValid()) {
      alert('Order placed successfully! Thank you for shopping with us. Order will be delivered to doorstep soon..');
      this.cartService.clearCart();
      this.router.navigate(['/']);
    } else {
      alert('Please fill all required fields and select payment method.');
    }
  }

  private isShippingValid(): boolean {
    return Object.values(this.shipping).every(val => val.trim() !== '');
  }
}
