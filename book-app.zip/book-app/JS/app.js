angular.module('bookApp', ['ngRoute'])
.config(function($routeProvider) {
  $routeProvider
    .when("/", {
      templateUrl: "partials/book-list.html",
      controller: "BookListController"
    })
    .when("/add", {
      templateUrl: "partials/add-book.html",
      controller: "AddBookController"
    })
    .when("/edit/:id", {
      templateUrl: "partials/edit-book.html",
      controller: "EditBookController"
    })
    .otherwise({ redirectTo: '/' });
});
