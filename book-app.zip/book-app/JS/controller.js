angular.module('bookApp')
.controller('BookListController', function($scope, BookService) {
  $scope.books = BookService.getBooks();

  $scope.deleteBook = function(id) {
    BookService.deleteBook(id);
    $scope.books = BookService.getBooks();
  };
})
.controller('AddBookController', function($scope, $location, BookService) {
  $scope.book = {};
  $scope.addBook = function() {
    BookService.addBook($scope.book);
    $location.path('/');
  };
})
.controller('EditBookController', function($scope, $routeParams, $location, BookService) {
  const id = $routeParams.id;
  $scope.book = angular.copy(BookService.getBook(id));

  $scope.updateBook = function() {
    BookService.updateBook($scope.book);
    $location.path('/');
  };
});
