angular.module('bookApp')
.factory('BookService', function() {
  let books = [
    { id: 1, title: "1984", author: "George Orwell", genre: "Dystopian", year: 1949 },
    { id: 2, title: "To Kill a Mockingbird", author: "Harper Lee", genre: "Classic", year: 1960 }
  ];

  return {
    getBooks: () => books,
    getBook: (id) => books.find(book => book.id === parseInt(id)),
    addBook: (book) => {
      book.id = books.length ? books[books.length - 1].id + 1 : 1;
      books.push(book);
    },
    updateBook: (updatedBook) => {
      const index = books.findIndex(b => b.id === updatedBook.id);
      if (index > -1) books[index] = updatedBook;
    },
    deleteBook: (id) => {
      books = books.filter(b => b.id !== id);
    }
  };
});
